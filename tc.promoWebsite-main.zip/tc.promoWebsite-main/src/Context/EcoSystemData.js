export const topSegment = [
    {
        heading:'Support Organization',
    },
    {
        heading:'Big Compaies',
    },
    {
        heading:'Universities',
    },
    {
        heading:'Funding Organization',
    },
    {
        heading:'Service Providers'
    },
    {
        heading:'Research Organization'
    }

]