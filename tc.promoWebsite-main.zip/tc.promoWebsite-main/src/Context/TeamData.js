import trial from "../Assests/About/trial.png";

export const teamData = [

];